﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Topshelf;

namespace TopShelfWCDemo
{
    public static class ServiceInitialier
    {
        public static void Initialize()
        {
            HostFactory.Run(configure =>
            {
                configure.Service<DemoService>(service =>
                {
                    service.ConstructUsing(s => new DemoService());
                    service.WhenStarted(s => s.Start());
                    service.WhenStopped(s => s.Stop());
                });
                configure.RunAsLocalSystem();
                configure.SetServiceName("TopShelf Demo");
                configure.SetDisplayName("TopShelf Demo");
                configure.SetDescription("sample windows service using topshelf");
            });
        }
    }
}
