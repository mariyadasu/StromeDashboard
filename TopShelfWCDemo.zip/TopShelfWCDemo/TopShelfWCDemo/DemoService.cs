﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TopShelfWCDemo
{
    public class DemoService
    {
        public void Start()
        {
            Console.WriteLine("DemoService started"); 
        }
        public void Stop()
        {
            Console.WriteLine("DemoService stoped");
        }
    }
}
