﻿using MySql.Data.MySqlClient;
using quad.ms.registration.services.MessageClient;
using quad.ms.registration.services.Models;
using quad.ms.sharedmodels;
using System;
using System.Collections.Generic;
using System.Text;

namespace quad.ms.registration.services.Services
{
    public class Registration : IRegistration
    {
        private readonly IRabbitMQClient _rabbitMQClient;
        private readonly string _connection;

        private readonly string _insertUserQuary = @"insert into userdetails(Name,Email,Mobile) values(@name,@email,@mobile);";

        public Registration()
        {
            _rabbitMQClient = new MessageUserClient();
            _connection = "uid=root;SslMode=none;pwd=Quad@123;server=localhost;Port=3306;Database=registration;Connect Timeout=1000000000";
        }
        public void PublishEmailMessage(EmailModel email)
        {
            //publish message
            _rabbitMQClient.PublishEmail(email);
        }

        public bool SaveUser(RegistrationModel userInfo)
        {
            try
            {
                using (var conn = new MySqlConnection(_connection))
                {
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand(_insertUserQuary, conn);
                    cmd.Parameters.AddWithValue("@name", userInfo.Name);
                    cmd.Parameters.AddWithValue("@email", userInfo.Email);
                    cmd.Parameters.AddWithValue("@mobile", userInfo.Mobile);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {

            }
            
            return true;
        }
    }
}
