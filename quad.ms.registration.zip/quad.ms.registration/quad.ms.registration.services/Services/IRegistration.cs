﻿using quad.ms.registration.services.Models;
using quad.ms.sharedmodels;
using System;
using System.Collections.Generic;
using System.Text;

namespace quad.ms.registration.services.Services
{
    public interface IRegistration
    {
        bool SaveUser(RegistrationModel userInfo);
        void PublishEmailMessage(EmailModel email);
    }
}
