﻿using quad.ms.sharedmodels;
using RabbitMQ.Client;
using System;
using System.Collections.Generic;
using System.Text;

namespace quad.ms.registration.services.MessageClient
{
    public interface IRabbitMQClient
    {
        IConnection CreateConnection();
        IModel CreateModel(IConnection connection);
        IBasicProperties CreateBasicProperties(IModel model);
        void PublishEmail(EmailModel email);
    }
}
