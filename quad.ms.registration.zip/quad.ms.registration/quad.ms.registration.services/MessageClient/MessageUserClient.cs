﻿using quad.ms.registration.services.MessageClient;
using quad.ms.sharedmodels;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System;
using System.Collections.Generic;
using System.Text;

namespace quad.ms.registration.services
{
    public class RabbitMqConfig
    {
        public string Host { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string Excahnge { get; set; }
        public string ExchangeType { get; set; }
        public string QueueName { get; set; }
    }
    public class MessageUserClient : IRabbitMQClient
    {
        private readonly RabbitMqConfig _rabbitMqConfig;
        public MessageUserClient()
        {
            //Move this to configurations
            _rabbitMqConfig = new RabbitMqConfig()
            {
                Host = "localhost",
                UserName = "guest",
                Password = "guest",
                Excahnge = "registration",
                ExchangeType = "fanout",
                QueueName = "registration"
            };
        }
        public IBasicProperties CreateBasicProperties(IModel model)
        {
            if (model == null)
            {
                return null;
            }

            return model.CreateBasicProperties();
        }

        public IConnection CreateConnection()
        {
            ConnectionFactory factory = new ConnectionFactory
            {
                HostName = _rabbitMqConfig.Host,
                UserName = _rabbitMqConfig.UserName,
                Password = _rabbitMqConfig.Password
            };

            return factory.CreateConnection();
        }

        public IModel CreateModel(IConnection connection)
        {
            if (connection == null)
            {
                return null;
            }
            return connection.CreateModel();
        }

        public void PublishEmail(EmailModel email)
        {

            using (var connection = CreateConnection())
            using (var channel = connection.CreateModel())
            {
                channel.ExchangeDeclare(_rabbitMqConfig.Excahnge, _rabbitMqConfig.ExchangeType);

                string jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(email);
                var body = Encoding.UTF8.GetBytes(jsonString);
                channel.BasicPublish(_rabbitMqConfig.Excahnge, "", null, body);
            }
        }
    }
}
