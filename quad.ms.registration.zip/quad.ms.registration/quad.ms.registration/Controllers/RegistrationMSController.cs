﻿using Microsoft.AspNetCore.Mvc;
using quad.ms.registration.services.Models;
using quad.ms.registration.services.Services;
using quad.ms.sharedmodels;
using RabbitMQ.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace quad.ms.registration.Controllers
{
    [Route("api/RegistrationMS")]
    public class RegistrationMSController : ControllerBase
    {
        private readonly IRegistration _registration;
        public RegistrationMSController()
        {
            _registration = new Registration();
        }
        [HttpGet]
        public ActionResult<IEnumerable<string>> Get()
        {
            
            return new string[] { "value1", "value2" };
        }

        [HttpPost]
        public IActionResult Post([FromBody] RegistrationModel registration)
        {
            var result = _registration.SaveUser(registration);
            if (result)
            {
                _registration.PublishEmailMessage(new EmailModel()
                {
                    To= registration.Email,
                    From="mariyadasu67@gmail.com",
                    Subject= "Subject Subject Subject"
                });
                return Ok();
            }

            return BadRequest();
        }
    }
}
