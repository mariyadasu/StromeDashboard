﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace quad.ms.webgate.Core.Http
{
    public interface IHttpClient : IDisposable
    {
        HttpRequestHeaders RequestHeaders { get; }
        TimeSpan Timeout { set; }
        Uri BaseAddress { get; set; }
        Task<HttpResponseMessage> PostAsync(Uri requestUri, HttpContent content);
        Task<HttpResponseMessage> GetAsync(Uri requestUri);
    }
}
