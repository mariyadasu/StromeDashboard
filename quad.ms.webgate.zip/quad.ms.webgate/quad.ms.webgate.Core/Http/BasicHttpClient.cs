﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace quad.ms.webgate.Core.Http
{
    internal class BasicHttpClient : IHttpClient
    {
        private readonly HttpClient _internalClient;
        private readonly HttpClientHandler _clientHandler = new HttpClientHandler();

        public BasicHttpClient()
        {
            _internalClient = new HttpClient(_clientHandler);
        }

        public TimeSpan Timeout
        {
            set { _internalClient.Timeout = value; }
        }
        public Uri BaseAddress
        {
            get { return _internalClient.BaseAddress; }
            set { _internalClient.BaseAddress = value; }
        }

        public HttpRequestHeaders RequestHeaders
        {
            get { return _internalClient.DefaultRequestHeaders; }
        }

        public void Dispose()
        {
           
            _internalClient.Dispose();
        }

        public async Task<HttpResponseMessage> PostAsync(Uri requestUri, HttpContent content)
        {
            var payload = content.ReadAsStringAsync().Result;
            var httpRequestMessage = TryEnhanceMessage(new HttpRequestMessage(HttpMethod.Post, requestUri)
            {
                Content = content
            });

            try
            {
              
                var postAsync = await _internalClient.SendAsync(httpRequestMessage).ConfigureAwait(false);
               
                return postAsync;
            }
            catch (Exception e)
            {
             
                throw;
            }

        }

        public async Task<HttpResponseMessage> GetAsync(Uri requestUri)
        {
            var httpRequestMessage = TryEnhanceMessage(new HttpRequestMessage(HttpMethod.Get, requestUri));

            var getAsync = await _internalClient.SendAsync(httpRequestMessage).ConfigureAwait(false);

            return getAsync;
        }

        private HttpRequestMessage TryEnhanceMessage(HttpRequestMessage httpRequestMessage)
        {
            return httpRequestMessage;
        }

    }
}
