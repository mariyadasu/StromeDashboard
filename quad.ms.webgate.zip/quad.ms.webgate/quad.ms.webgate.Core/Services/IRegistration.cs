﻿using quad.ms.webgate.Core.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace quad.ms.webgate.Core.Services
{
    public interface IRegistration
    {
        bool SaveUserDetails(RegistrationModel userDetails);
    }
}
