﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using quad.ms.webgate.Core.Http;
using quad.ms.webgate.Core.Models;

namespace quad.ms.webgate.Core.Services
{
    public class Registration : IRegistration
    {
        private IHttpClient _httpClient;
        private const string REGBASEURI= "http://localhost:63059/api/";
        private const string REGMETHOD= "RegistrationMS";
        public Registration()
        {
            _httpClient = new BasicHttpClient();
        }
        public bool SaveUserDetails(RegistrationModel userDetails)
        {
            if (userDetails == null)
                return false;

            string jsonRequest = JsonConvert.SerializeObject(userDetails, new JsonSerializerSettings
            {
                ContractResolver = new CamelCasePropertyNamesContractResolver()
            });

            var request = new StringContent(jsonRequest);
            request.Headers.ContentType = new MediaTypeHeaderValue("application/json");

            _httpClient.BaseAddress = new Uri(REGBASEURI);

            var result = _httpClient.PostAsync(new Uri(REGBASEURI + REGMETHOD), request).Result;
            result.EnsureSuccessStatusCode();
            var response = result.Content.ReadAsStringAsync().Result;
            return true;
        }
    }
}
