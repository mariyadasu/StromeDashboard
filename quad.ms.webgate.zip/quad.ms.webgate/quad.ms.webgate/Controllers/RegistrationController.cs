﻿using Microsoft.AspNetCore.Mvc;
using quad.ms.webgate.Core.Models;
using quad.ms.webgate.Core.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace quad.ms.webgate.Controllers
{
    [Route("api/Registration")]
    [ApiController]
    public class RegistrationController: ControllerBase
    {
        private readonly IRegistration _registration;
        public RegistrationController()
        {
            _registration = new Registration();
        }
        // GET api/values
        [HttpGet]
        public ActionResult<IEnumerable<string>> Get()
        {
            return new string[] { "value1", "value2" };
        }
        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody] RegistrationModel registration)
        {
            var result = _registration.SaveUserDetails(registration);
            if (result)
            {
               return Ok();
            }

            return BadRequest();
        }
    }
}
