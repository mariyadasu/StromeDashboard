import { Component } from '@angular/core';

import { RegistrationServce } from './services/registration.service'
import { UserDetails } from './models/registration';
import { userInfo } from 'os';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'mss-demo';
  userInfo: UserDetails = {};

  constructor(private registrationServce: RegistrationServce) {

  }
  register() {
    if (!this.userInfo.name || this.userInfo.name == ''
      || !this.userInfo.email || this.userInfo.email == ''
      || !this.userInfo.mobile || this.userInfo.mobile == '') {
      alert('Please fill missing information');
      return;
    }

    this.registrationServce.regusterUser(this.userInfo).subscribe(data => {
      alert('registration successfully completed');
      this.userInfo={};
    },
      error => {
        alert('Error while registration');
        console.log('oops', error)
      });
  }
}
