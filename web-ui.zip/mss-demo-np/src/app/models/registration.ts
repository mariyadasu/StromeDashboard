
export interface UserDetails{
    name?:string,
    email?:string,
    mobile?:string,
    address?:string
}