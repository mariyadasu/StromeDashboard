
import { HttpClient } from '@angular/common/http';
import { Injectable, OnDestroy, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { UserDetails } from '../models/registration';
import { Observable } from 'rxjs';

@Injectable()
export class RegistrationServce implements OnInit {

    baseUri = "http://localhost:55788/api/";
    constructor(
        private httpClient: HttpClient) { }

    ngOnInit() {

    }

    regusterUser(userInfo: UserDetails): Observable<any> {

        return this.httpClient.post(this.baseUri+"Registration",userInfo);
    }
}
