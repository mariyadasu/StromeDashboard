﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;
using quad.ms.emailservice.core.Services;
using quad.ms.sharedmodels;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;

namespace quad.ms.emailservice.core.MessageClient
{
    public class RabbitMqConfig
    {
        public string Host { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string Excahnge { get; set; }
        public string ExchangeType { get; set; }
        public string QueueName { get; set; }
    }
    public class MessageUserClient : IRabbitMQClient
    {
        private readonly RabbitMqConfig _rabbitMqConfig;
        private readonly IRegistration _registration;
        public MessageUserClient()
        {
            //Move this to configurations
            _rabbitMqConfig = new RabbitMqConfig()
            {
                Host = "localhost",
                UserName = "guest",
                Password = "guest",
                Excahnge = "registration",
                ExchangeType = "fanout",
                QueueName = "registration"
            };
            _registration = new Registration();
        }
        public IBasicProperties CreateBasicProperties(IModel model)
        {
            if (model == null)
            {
                return null;
            }

            return model.CreateBasicProperties();
        }

        public IConnection CreateConnection()
        {
            ConnectionFactory factory = new ConnectionFactory
            {
                HostName = _rabbitMqConfig.Host,
                UserName = _rabbitMqConfig.UserName,
                Password = _rabbitMqConfig.Password
            };

            return factory.CreateConnection();
        }

        public IModel CreateModel(IConnection connection)
        {
            if (connection == null)
            {
                return null;
            }
            return connection.CreateModel();
        }

        public void Start()
        {
            
            using (var connection = CreateConnection())
            {
                using (var channel = connection.CreateModel())
                {
                    channel.ExchangeDeclare(_rabbitMqConfig.Excahnge, _rabbitMqConfig.ExchangeType);

                    channel.QueueBind(_rabbitMqConfig.QueueName, _rabbitMqConfig.Excahnge, "");
                    var consumer = new QueueingBasicConsumer(channel);
                    channel.BasicConsume(_rabbitMqConfig.QueueName, true, consumer);

                    while (true)
                    {
                        var ea = (BasicDeliverEventArgs)consumer.Queue.Dequeue();
                        var body = ea.Body;
                        var message = Encoding.UTF8.GetString(body);
                        var emilData= JsonConvert.DeserializeObject<EmailModel>(message);
                        _registration.SaveEmailData(emilData);
                    }
                }
            }
        }
    }
}
