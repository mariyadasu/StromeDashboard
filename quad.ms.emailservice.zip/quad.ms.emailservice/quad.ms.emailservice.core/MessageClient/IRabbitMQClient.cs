﻿using RabbitMQ.Client;
using System;
using System.Collections.Generic;
using System.Text;

namespace quad.ms.emailservice.core.MessageClient
{
    public interface IRabbitMQClient
    {
        IConnection CreateConnection();
        IModel CreateModel(IConnection connection);
        IBasicProperties CreateBasicProperties(IModel model);
        void Start();
    }
}
