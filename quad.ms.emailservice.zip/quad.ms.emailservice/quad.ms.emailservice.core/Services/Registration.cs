﻿using System;
using System.Collections.Generic;
using System.Text;
using MySql.Data.MySqlClient;
using quad.ms.sharedmodels;

namespace quad.ms.emailservice.core.Services
{
    public class Registration : IRegistration
    {
        private readonly string _connection;
        private readonly string _insertUserQuary = @"insert into emaildata(FromEmail,ToEmail,SubjectText) values(@from,@to,@subject);";
        public Registration()
        {
            _connection = "uid=root;SslMode=none;pwd=Quad@123;server=localhost;Port=3306;Database=email;Connect Timeout=1000000000";
        }
        public void SaveEmailData(EmailModel emailData)
        {
            try
            {
                using (var conn = new MySqlConnection(_connection))
                {
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand(_insertUserQuary, conn);
                    cmd.Parameters.AddWithValue("@from", emailData.From);
                    cmd.Parameters.AddWithValue("@to", emailData.To);
                    cmd.Parameters.AddWithValue("@subject", emailData.Subject);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {

            }
        }
    }
}
