﻿using quad.ms.sharedmodels;
using System;
using System.Collections.Generic;
using System.Text;

namespace quad.ms.emailservice.core.Services
{
    public interface IRegistration
    {
        void SaveEmailData(EmailModel emailData);
    }
}
